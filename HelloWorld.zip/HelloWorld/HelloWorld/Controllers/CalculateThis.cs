﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Text.Encodings.Web;

namespace HelloWorld.Controllers
{
    public class CalculateThis : Controller
    {
        // GET: /HelloWorld/CalculateThis/
        public string Welcome(string name, int numTimes = 1)
        {
            return HtmlEncoder.Default.Encode($"Hello {name}, ID: {numTimes}");
        }
    }
}
